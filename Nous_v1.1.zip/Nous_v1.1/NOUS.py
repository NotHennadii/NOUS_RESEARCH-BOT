import requests
import random
import time
import threading
from itertools import cycle
from rich.text import Text
from rich.console import Console
from datetime import datetime

console = Console()

API_URL = "https://inference-api.nousresearch.com/v1/chat/completions"

MODEL_WEIGHTS = {
    "Hermes-3-Llama-3.1-405B": 5,
    "Hermes-3-Llama-3.1-70B": 15,
    "DeepHermes-3-Mistral-24B-Preview": 30,
    "DeepHermes-3-Llama-3-8B-Preview": 50
}

def choose_model():
    models = list(MODEL_WEIGHTS.keys())
    weights = list(MODEL_WEIGHTS.values())
    return random.choices(models, weights=weights, k=1)[0]

request_counter = 0
counter_lock = threading.Lock()

def print_banner():
    banner_text = Text(
        """
*--------------------------------------------------------------------------*..=#####**=.  
*                            ...:-==++++==-:..                             *..=##=::+##=. 
*                       .:-:.....::-+*######***+-.                         *..=##*++*#*-. 
*                   .-+*********+:. ...=*########**=.                      *..=##*++=-..  
*                .=*###############*:   .-###########+.                    *..=##-.       
*            ..-*####################*:.  .+###########+..                 *..=**-.       
*          ..=#####################****=.. .-*#######**#:-.                *.   .....     
*        ..=*#####**###########++*+. .-++.  .-*##*##*+:=.==.               *...-**##*=:.  
*       .:=+*####++*##*+***###*+:-...-+*==   .==+:=+=.. -**=.              *..+#*=::*#*-. 
*      .:-:::+*++-:-==:::  --:.. .=**###**+   .+*==***++**#*-.             *.-##+.  -##+. 
*      :=:...::======++****+*+-==+*#######*:   :##**###**###*:             *.-##+.  -##+. 
*     .*+******#*##########################+.-=+*############*.            *..*#*-..*#*-. 
*     =#################**#################*-+#=*###**########-            *...=*####*:.  
*    .*#################*+*################***##++*##+*########.           *........      
*    :*##################=+*##########################*########-           *..+******+-.. 
*    :*##########*+*#####*-+##########################**#######*.          *..+##=--*##=. 
*    .*##########*=:=+=++=-::=======+**################=#######*:          *..+##===*#*-. 
*     :*######*==:   ..:=*#**+-..    .=################**######*=.         *..+##+*##+:.  
*      .+#***#*=+=:.   .--*##+-++..  .=######+===-+#####+*######+.         *..+##:.*#*=.  
*      ...=+-+#*=#+.   ..::=+-=-..   .=#################*+######*-         *..+##:.:##*:. 
*          ..:#*==:.    ........     :+##################**######=.        *....... ..... 
*            -#*:                   .-###################*+*#####*:        *..+********:  
*            +*+-.:..               .-####################**######=.       *..=++*##*++:  
*           .**-.::                 :+####################***#####*:.      *.   .+##-     
*           .**=.-:..              .:######################**######-.      *.   .+##-     
*           :*#*:-*++=-:           .-######*###############**##**##*.      *.   .+##-     
*           -*#*+:--....           .*#####*-###################**+##=      *.   .+##-     
*    ..    .+###*+:..              :######-:####################+-*#*.     *.   ..::.     
*  .-:.    .+#####+.               :#####*.:*###################+:=##-     *.   :+++-     
*  -+:     -*######+.              =#####+######################+.=*#*.::  *.  .+###*:    
* .=*:.   .+#########*+***###*+:.  +####**-.-###################+.=*##.:+-.*. .-**+##+.   
* .=**=:::+###**###############*-. -####*...=##################*-:*###..+=.*. :+#=.*#*-.  
* :=+*######*+-##################==#*#####*####################*:+####.:++.*..=#######+:  
* .=+=+*#*+=:=###**###############+::*#########################=*####*.-*+.*.:**=:::+##=. 
*  .=*+=---=*###*+*############*+:. ..=*#############################::**-.*.:-:.   .--:. 
*   ..=*#######+-+###########*=..     ..:+#############*############--**=. *. .-==:       
*      ..:+=::.:*#############*=.     .:+**++-=*#+-::::-=+--*#####*-+#*=.  *. .=##-       
*        .-****###++*###########=. .-**+:.:.=**:.       ..:+==###***#=..   *. .=##-       
*          .:=++-.:*###########*#***+:..-.:**-.             -*-*#*=..      *. .=##-       
*               .:+##########*+*+..  .::.+*+.                .*=+.         *. .=##-....   
*...............-*#####**+=**+*-....:+=.:*-....................=:..........*. .=##****+.  
----------------------------------------------------------------------------. .:------:.          

                         [NOUS RESEARCH FUCKER BOT v1.1]
                Built for the bleak cold vacuum of rate limits 
          
""",
        style="bold cyan"
    )
    console.print(banner_text)

def load_lines(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return [line.strip() for line in f if line.strip()]
    except FileNotFoundError:
        console.print(f"❌ Файл не найден: {file_path}", style="red")
        return []

def send_prompt(prompt_text, api_key, system_prompt, proxy=None):
    global request_counter
    model_name = choose_model()

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": model_name,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": prompt_text}
        ],
        "temperature": 0.7,
        "max_tokens": 1024
    }
    proxies = {"http": proxy, "https": proxy} if proxy else None

    start_time = datetime.now()
    try:
        response = requests.post(API_URL, headers=headers, json=payload, proxies=proxies, timeout=20)
        elapsed = (datetime.now() - start_time).total_seconds()
        if response.status_code == 200:
            content = response.json()["choices"][0]["message"]["content"]
            with counter_lock:
                request_counter += 1
                current_count = request_counter
            console.print(f"\n[{datetime.now().strftime('%H:%M:%S')}] ✅ Запрос #{current_count} (модель: {model_name}):\n{prompt_text}\n[green]{content}[/green]\nВремя запроса: {elapsed:.2f} сек\n{'-'*60}")
            with open("log.txt", "a", encoding="utf-8") as f:
                f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] Запрос #{current_count} (модель: {model_name}):\nВопрос: {prompt_text}\nОтвет: {content}\nВремя запроса: {elapsed:.2f} сек\n{'='*80}\n")
        elif response.status_code == 429:
            console.print(f"⏳ Rate limit на ключ: {api_key} — ждем 10 секунд и повторяем...", style="yellow")
            time.sleep(10)
            return send_prompt(prompt_text, api_key, system_prompt, proxy)
        else:
            console.print(f"❌ Ошибка {response.status_code}: {response.text}\n{'-'*60}", style="red")
    except Exception as e:
        console.print(f"❌ Ошибка при запросе: {e}\n{'-'*60}", style="red")

def generate_question(api_key, system_prompt, proxy=None, lang='r'):
    model_name = choose_model()

    if lang == 'r':
        gen_prompt = "Придумай уникальный вопрос на русском языке на тему технологий, криптовалют или философии."
    elif lang == 'e':
        gen_prompt = "Generate a unique question in English about technology, cryptocurrency or philosophy."
    else:
        gen_prompt = random.choice([
            "Придумай уникальный вопрос на русском языке на тему технологий, криптовалют или философии.",
            "Generate a unique question in English about technology, cryptocurrency or philosophy."
        ])

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": model_name,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": gen_prompt}
        ],
        "temperature": 0.8,
        "max_tokens": 50
    }
    proxies = {"http": proxy, "https": proxy} if proxy else None

    start_time = datetime.now()
    try:
        response = requests.post(API_URL, headers=headers, json=payload, proxies=proxies, timeout=20)
        elapsed = (datetime.now() - start_time).total_seconds()
        if response.status_code == 200:
            content = response.json()["choices"][0]["message"]["content"].strip()
            question = content.split('\n')[0]
            console.print(f"[{datetime.now().strftime('%H:%M:%S')}] 🎯 Сгенерирован вопрос за {elapsed:.2f} сек (модель: {model_name})", style="blue")
            return question
        elif response.status_code == 429:
            console.print(f"⏳ Rate limit при генерации вопроса. Ждем 10 секунд...", style="yellow")
            time.sleep(10)
            return generate_question(api_key, system_prompt, proxy, lang)
        else:
            console.print(f"❌ Ошибка генерации вопроса {response.status_code}: {response.text}", style="red")
            return None
    except Exception as e:
        console.print(f"❌ Ошибка при генерации вопроса: {e}", style="red")
        return None

def worker(index, count, delay_range, keys_cycle, proxies_cycle, system_prompt, lang_choice):
    for i in range(count):
        api_key = next(keys_cycle)
        proxy = next(proxies_cycle) if proxies_cycle else None
        lang = random.choice(['r', 'e']) if lang_choice == 'both' else lang_choice
        question = generate_question(api_key, system_prompt, proxy, lang)
        if not question:
            continue
        console.print(f"🟡 Поток {index} [{i+1}/{count}] Вопрос: {question} Прокси: {proxy or 'none'}")
        send_prompt(question, api_key, system_prompt, proxy)
        if i < count - 1:
            sleep_time = random.uniform(delay_range[0], delay_range[1])
            console.print(f"⏳ Поток {index} пауза {sleep_time:.2f} сек\n{'-'*40}", style="dim")
            time.sleep(max(0.1, sleep_time))

def format_proxies(raw_proxies):
    formatted = []
    for line in raw_proxies:
        if "@" not in line and line.count(":") == 3:
            login, password, ip, port = line.split(":")
            formatted.append(f"http://{login}:{password}@{ip}:{port}")
        else:
            formatted.append(line)
    return formatted

def get_user_inputs():
    try:
        count = int(input("🔢 Введите количество запросов (default 5): ") or 5)
        delay_input = input("⏱ Введите задержку между запросами (например '1 3', default 3): ") or "3"
        delay_parts = delay_input.strip().split()
        if len(delay_parts) == 2:
            delay_min, delay_max = float(delay_parts[0]), float(delay_parts[1])
            if delay_min > delay_max:
                delay_min, delay_max = delay_max, delay_min
        else:
            delay_min = delay_max = float(delay_parts[0])
        threads = int(input("🧵 Введите количество потоков (default 1): ") or 1)
        use_proxy_input = input("🌐 Использовать прокси? (y/n, default n): ").strip().lower()
        use_proxy = use_proxy_input == 'y'
        lang_choice_input = input("🌍 Язык (r - русский, e - английский, both - оба, default r): ").strip().lower()
        lang_choice = lang_choice_input if lang_choice_input in ['r', 'e', 'both'] else 'r'
        return count, (delay_min, delay_max), threads, use_proxy, lang_choice
    except Exception:
        console.print("❌ Некорректный ввод. Попробуйте снова.", style="red")
        return get_user_inputs()

def main():
    print_banner()
    count, delay_range, threads, use_proxy, lang_choice = get_user_inputs()

    console.print(f"\nПараметры запуска:\n- Запросов на поток: {count}\n- Задержка: от {delay_range[0]} до {delay_range[1]} сек\n- Потоков: {threads}\n- Использование прокси: {use_proxy}\n- Язык: {lang_choice}\n", style="cyan")
    input("Нажмите Enter для запуска...")

    api_keys = load_lines("API_keys.txt")
    if not api_keys:
        return console.print("❌ Нет API ключей.", style="red")

    system_prompt = "\n".join(load_lines("promt.txt")) or "You are a helpful assistant."

    proxies_cycle = None
    if use_proxy:
        raw_proxies = load_lines("proxy.txt")
        if not raw_proxies:
            return console.print("❌ Не найдены прокси в proxy.txt.", style="red")
        formatted = format_proxies(raw_proxies)
        proxies_cycle = cycle(formatted)

    keys_cycle = cycle(api_keys)

    threads_list = []
    for i in range(threads):
        t = threading.Thread(target=worker, args=(i+1, count, delay_range, keys_cycle, proxies_cycle, system_prompt, lang_choice))
        t.start()
        threads_list.append(t)

    for t in threads_list:
        t.join()

if __name__ == "__main__":
    main()